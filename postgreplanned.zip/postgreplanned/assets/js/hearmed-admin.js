/* HearMed Admin Console JS — CRUD modals, table sorting, admin interactions */
