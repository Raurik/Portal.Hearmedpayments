/* HearMed Reports JS — report filters, chart rendering, PDF/Excel export */
