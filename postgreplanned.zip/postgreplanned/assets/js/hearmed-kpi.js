/* HearMed KPI JS — dashboard gauges, targets, trend charts */
